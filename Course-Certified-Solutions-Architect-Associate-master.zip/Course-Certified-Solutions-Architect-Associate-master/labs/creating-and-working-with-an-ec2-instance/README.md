# Lab: Creating and Working with an EC2 Instance
