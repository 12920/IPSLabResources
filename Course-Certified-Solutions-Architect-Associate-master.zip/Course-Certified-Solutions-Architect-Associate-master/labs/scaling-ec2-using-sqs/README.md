# Lab: Scaling EC2 Using SQS
