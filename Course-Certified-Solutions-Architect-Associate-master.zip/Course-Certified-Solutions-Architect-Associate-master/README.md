# AWS Certified Solutions Architect - Associate
