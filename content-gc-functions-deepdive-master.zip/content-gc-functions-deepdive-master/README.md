# content-gc-functions-deepdive
